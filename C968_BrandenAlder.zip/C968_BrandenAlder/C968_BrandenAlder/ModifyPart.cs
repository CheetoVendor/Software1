﻿using C968_BrandenAlder.Models;
using System;
using System.Windows.Forms;

namespace C968_BrandenAlder
{
    public partial class ModifyPart : Form
    {
        public ModifyPart(Part part)
        {
            InitializeComponent();
            // Fill in fields
            FillFields(part);
        }

        #region Events
        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
            // Try parsing all the values
                int partID = int.Parse(idTextBox.Text);
                string name = nameTextBox.Text;
                int inventory = int.Parse(inventoryTextBox.Text);
                decimal price = decimal.Parse(priceCostTextBox.Text);
                int min = int.Parse(minTextBox.Text);
                int max = int.Parse(maxTextBox.Text);

                // Exception check: Check values are within range
                if (min > max)
                {
                    MessageBox.Show("Minimum quantity of parts can not be greater than maximum.");
                    return;
                }
                if (inventory < min || inventory > max)
                {
                    MessageBox.Show("The quantity of items in inventory must be between the minimum and maximum values.");
                    return;
                }

                // Update part based on radio button selection
                if (inhouseRadioButton.Checked)
                {
                    int machineID = int.Parse(machineIdTextBox.Text);
                    Inventory.UpdatePart(partID, new Inhouse(partID, machineID ,name, inventory, price, min, max));
                    this.Close();
                }
                else
                {
                    Inventory.UpdatePart(partID, new Outsourced(partID, machineIdTextBox.Text, name, inventory, price, min, max));
                    this.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Machine ID, Inventory, Min, max, and price need to be numbers.");
            }
            
        }

        private void inhouseRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            changingLabel.Text = "Machine ID";
        }

        private void outsourcedRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            changingLabel.Text = "Company Name";
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion
        #region Methods
        private void FillFields(Part part)
        {
            idTextBox.Text = part.PartID.ToString();
            nameTextBox.Text = part.Name;
            inventoryTextBox.Text = part.InStock.ToString();
            priceCostTextBox.Text = part.Price.ToString();
            maxTextBox.Text = part.Max.ToString();
            minTextBox.Text = part.Min.ToString();

            if(part is Inhouse)
            {
                machineIdTextBox.Text = ((Inhouse)part).MachineID.ToString();
            }
            else
            {
                outsourcedRadioButton.Checked = true;
                machineIdTextBox.Text = ((Outsourced)part).CompanyName;
            }
        }
        #endregion
    }
}
