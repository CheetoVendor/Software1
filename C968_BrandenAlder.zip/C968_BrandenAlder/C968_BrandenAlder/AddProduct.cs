﻿using C968_BrandenAlder.Models;
using System;
using System.Windows.Forms;

namespace C968_BrandenAlder
{
    public partial class AddProduct : Form
    {
        Product newProduct = new Product();
        
        public AddProduct()
        {
            InitializeComponent();

            // Bind all parts to grid
            var allPartsBinding = new BindingSource();
            allPartsBinding.DataSource = Inventory.AllParts;
            allPartsGrid.DataSource = allPartsBinding;

            // bind associated product's parts to bottom grid
            var associatedPartsBinding = new BindingSource();
            associatedPartsBinding.DataSource = newProduct.AssociatedParts;
            associatedPartsGrid.DataSource = associatedPartsBinding;

            // auto increment ID based on count
            idTextBox.Text = Inventory.Products.Count.ToString();
        }
        #region Events
        private void searchCandidatePartsButton_Click(object sender, EventArgs e)
        {
            bool found = false;

            // Search by ID
            if (int.TryParse(searchPartsBox.Text, out int id))
            {
                Part searchedPart = Inventory.LookupPart(id);

                if (searchedPart == null)
                {
                    MessageBox.Show("Part not found");
                    return;
                }

                foreach (DataGridViewRow item in allPartsGrid.Rows)
                {
                    if (((Part)item.DataBoundItem).PartID == searchedPart.PartID)
                    {
                        item.Selected = true;
                        found = true;
                        break;
                    }
                }
            }
            else // Search by name
            {
                Part searchedPart = Inventory.LookupPart(searchPartsBox.Text);

                if (searchedPart == null)
                {
                    MessageBox.Show("Part not found");
                    return;
                }

                foreach (DataGridViewRow item in allPartsGrid.Rows)
                {
                    if (((Part)item.DataBoundItem) == searchedPart)
                    {
                        item.Selected = true;
                        found = true;
                        break;
                    }
                }
            }
            if (!found)
            {
                MessageBox.Show("Part not found.");
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            newProduct.AddAssociatedPart((Part)allPartsGrid.SelectedRows[0].DataBoundItem);
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            // Verify if user wants to delete part
            if (MessageBox.Show("Are you sure you want to delete this part?", "Delete Part?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                associatedPartsGrid.Rows.Remove(associatedPartsGrid.SelectedRows[0]);
            }
            else
            {
                return;
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
            // Try parsing all the values
                int productID = int.Parse(idTextBox.Text);
                string name = nameTextBox.Text;
                int inventory = int.Parse(inventoryTextBox.Text);
                decimal price = decimal.Parse(priceCostTextBox.Text);
                int min = int.Parse(minTextBox.Text);
                int max = int.Parse(maxTextBox.Text);

                // Exception check to make sure everything is in range 
                if (min > max)
                {
                    MessageBox.Show("Minimum quantity of parts can not be greater than maximum.");
                    return;
                }
                if (inventory < min || inventory > max)
                {
                    MessageBox.Show("The quantity of items in inventory must be between the minimum and maximum values.");
                    return;
                }

                // Assign new values
                newProduct.ProductID = productID;
                newProduct.Name = name;
                newProduct.InStock = inventory;
                newProduct.Price = price;
                newProduct.Min = min;
                newProduct.Max = max;

                // Add prod to inventory then close
                Inventory.AddProduct(newProduct);
                this.Close(); 
            }
            catch (Exception ex)
            { 
                MessageBox.Show("Inventory, Min, max, and price need to be numbers.");
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
