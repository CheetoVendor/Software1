﻿namespace C968_BrandenAlder.Models
{
    public class Inhouse : Part 
    {
        // Inhouse Prop
        public int MachineID { get; set; }

        // ctors
        public Inhouse(int partID, int machineID, string name, int inStock, decimal price, int min, int max) 
        {
            PartID = partID; 
            MachineID = machineID;
            Name = name;
            InStock = inStock;
            Price = price;
            Min = min;
            Max = max;
        }
    }
}
