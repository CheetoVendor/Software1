﻿namespace C968_BrandenAlder.Models
{
    public class Outsourced : Part
    {
        // Outsourced prop
        public string CompanyName { get; set; }
        // ctor
        public Outsourced(int partID, string companyName, string name, int inStock, decimal price, int min, int max)
        {
            PartID = partID;
            CompanyName = companyName;
            Name = name;
            InStock = inStock;
            Price = price;
            Min = min;
            Max = max;
        }
    }
}
