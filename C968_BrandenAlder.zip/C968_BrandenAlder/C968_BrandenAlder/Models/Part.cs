﻿namespace C968_BrandenAlder.Models
{
    public abstract class Part
    {   // Part abstract class
        public int PartID { get; set; }
        public string Name { get; set; }
        public int InStock { get; set; }
        public decimal Price { get; set; }
        public int Min { get; set; }
        public int Max { get; set; }
    }
}
