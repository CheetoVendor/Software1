﻿using System.ComponentModel;

namespace C968_BrandenAlder.Models
{
    public class Product
    {
        // Props
        public BindingList<Part> AssociatedParts { get; set; } = new BindingList<Part>();
        public int ProductID { get; set; }
        public string Name { get; set; }
        public int InStock { get; set; }
        public decimal Price { get; set; }
        public int Min { get; set; }
        public int Max { get; set; }

        // Ctors
        public Product(){}

        public Product(int ID, string name, decimal price, int instock, int min, int max)
        {
            ProductID = ID;
            Name = name;
            Price = price;
            InStock = instock;
            Min = min;
            Max = max;
        }

        // Methods
        public void AddAssociatedPart(Part part)
        {
            AssociatedParts.Add(part);
        }
        public bool RemoveAssociatedPart(int id)
        {
            foreach (Part part in AssociatedParts)
            {
                if(part.PartID == id)
                {
                    AssociatedParts.Remove(part);
                    return true;
                }
            }
            return false;
        }
        public Part LookupAssociatedPart(int id)
        {
            foreach (Part item in AssociatedParts)
            {
                if(item.PartID == id)
                {
                    return item;
                }
            }
            return null;
        }
    }
}
