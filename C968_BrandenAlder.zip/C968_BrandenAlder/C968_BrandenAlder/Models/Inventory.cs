﻿using System.ComponentModel;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace C968_BrandenAlder.Models
{
    public static class Inventory
    {
        // Props
        public static BindingList<Product> Products { get; set; } = new BindingList<Product>();
        public static BindingList<Part> AllParts { get; set; } = new BindingList<Part>();

        // Methods
        public static void AddProduct(Product product)
        {
            Products.Add(product);
        }
        public static bool RemoveProduct(int id)
        {
            foreach (var item in Products)
            {
                if (item.ProductID == id)
                {
                    Products.Remove(item);
                    return true;
                }
            }
            return false;
        }
        public static Product LookupProduct(int id)
        {
            foreach (Product product in Products)
            {
                if (product.ProductID == id)
                {
                    return product;
                }
            }
            return null;
        }
        public static Product LookupProduct(string name)
        {
            foreach (Product prod in Products)
            {
                if (prod.Name.Contains(name))
                {
                    return prod;
                }
            }
            return null;
        }
        public static void UpdateProduct(int id, Product product)
        {
            foreach (Product item in Products)
            {
                if (item.ProductID == product.ProductID)
                {
                    item.AssociatedParts = product.AssociatedParts;
                    item.ProductID = product.ProductID;
                    item.Name = product.Name;
                    item.InStock = product.InStock;
                    item.Price = product.Price;
                    item.Min = product.Min;
                    item.Max = product.Max;
                    break;
                }
            }
        }
        public static void AddPart(Part part)
        {
            AllParts.Add(part);
        }
        public static bool DeletePart(Part part)
        {
            // need to see if part is associated with any product
            foreach (Product product in Products)
            {
                if (product.AssociatedParts.Contains(part))
                {
                    return false;
                }
            }
            AllParts.Remove(part);
            return true;
        }
        public static Part LookupPart(int id)
        {
            foreach (Part part in AllParts)
            {
                if (part.PartID == id)
                {
                    return part;
                }
            }
            return null;
        }
        public static Part LookupPart(string name)
        {
            foreach (Part part in AllParts)
            {
                if (part.Name.Contains(name))
                {
                    return part;
                }
            }
            return null;
        }
        public static void UpdatePart(int id, Part part)
        {
            for (int i = 0; i < AllParts.Count; i++)
            {
                if (AllParts[i].PartID == id)
                {
                    if (AllParts[i] is Inhouse inhouse && part is Outsourced outs)
                    {
                        AllParts[i] = new Outsourced(outs.PartID, "", outs.Name, outs.InStock, outs.Price, outs.Min, outs.Max);
                        ((Outsourced)AllParts[i]).CompanyName = outs.CompanyName;
                        break;
                    }
                    else if (AllParts[i] is Outsourced && part is Inhouse inhousePart)
                    {
                        AllParts[i] = new Inhouse(inhousePart.PartID, 0, inhousePart.Name, inhousePart.InStock, inhousePart.Price, inhousePart.Min, inhousePart.Max);
                        ((Inhouse)AllParts[i]).MachineID = inhousePart.MachineID;
                        break;
                    }
                    else
                    {
                        AllParts[i] = part;
                    }
                }
            }
        }
    }
}
