﻿using C968_BrandenAlder.Models;
using System;
using System.Linq;
using System.Windows.Forms;

namespace C968_BrandenAlder
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }
        private void MainScreen_Load(object sender, EventArgs e)
        {
            // Bind data for Parts grid
            var partBinding = new BindingSource();
            partBinding.DataSource = Inventory.AllParts;
            partsGrid.DataSource = partBinding;

            // Bind data for products grid
            var productBinding = new BindingSource();
            productBinding.DataSource = Inventory.Products;
            productsGrid.DataSource = productBinding;

            // Change grid headers to match gui mockup
            partsGrid.Columns["PartID"].HeaderText = "Part ID";
            partsGrid.Columns["InStock"].HeaderText = "Inventory";
            productsGrid.Columns["ProductID"].HeaderText = "Product ID";
            productsGrid.Columns["InStock"].HeaderText = "Inventory";

            ////// Add fake data /////// 
            // Parts
            Inventory.AllParts.Add(new Inhouse(0, 1, "Cheeto dust", 500, 1, 10, 20000));
            Inventory.AllParts.Add(new Outsourced(1, "Potato place", "potatos", 500, 1, 10, 20000));
            Inventory.AllParts.Add(new Inhouse(2, 1, "New cheetodust flavor", 500, 1, 10, 20000));

            // Add product 
            Inventory.Products.Add(new Product(0, "Cheetos", 5, 100, 0, 500));

            // Associate parts with product
            Inventory.Products[0].AssociatedParts.Add(Inventory.AllParts[0]);
            Inventory.Products[0].AssociatedParts.Add(Inventory.AllParts[1]);
        }

        #region Parts Side Events 
        private void searchPartButton_Click(object sender, EventArgs e)
        {
            bool found = false;

            // Search by ID or NAME
            if (int.TryParse(partsTextBox.Text, out int id))
            {
                Part searchedPart = Inventory.LookupPart(id);
                if (searchedPart == null)
                {
                    MessageBox.Show("Part not found");
                    return;
                }


                foreach (DataGridViewRow item in partsGrid.Rows)
                {
                    if (((Part)item.DataBoundItem).PartID == searchedPart.PartID)
                    {
                        item.Selected = true;
                        found = true;
                        break;
                    }
                }
            }
            else // if it isnt int search for name
            {
                Part searchedPart = Inventory.LookupPart(partsTextBox.Text);

                foreach (DataGridViewRow item in partsGrid.Rows)
                {
                    if (((Part)item.DataBoundItem) == searchedPart)
                    {
                        item.Selected = true;
                        found = true;
                        break;
                    }
                }
            }
            if (!found || partsTextBox.Text == "")
            {
                MessageBox.Show("Part not found.");
            }
        }

        private void addPartButton_Click(object sender, EventArgs e)
        {
            new AddPartView().ShowDialog();
        }

        private void modifyPartButton_Click(object sender, EventArgs e)
        {
            new ModifyPart((Part)partsGrid.SelectedRows[0].DataBoundItem).ShowDialog();
        }
        private void deletePartButton_Click(object sender, EventArgs e)
        {
            // Verify if user wants to delete part
            if (MessageBox.Show("Are you sure you want to delete this part?", "Delete Part?", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                // TEST 3 of D1: Check if part is associated with product
                if (Inventory.DeletePart((Part)partsGrid.SelectedRows[0].DataBoundItem))
                {
                    // Nothing happens
                }
                else
                {
                    MessageBox.Show("Part is associated with a product and cannot be deleted.");
                }
            }
            else
            {
                return;
            }

        }
        #endregion
        #region Products Side Events
        private void searchProductButton_Click(object sender, EventArgs e)
        {
            bool found = false;

            // Search by ID or NAME
            if (int.TryParse(productsTextBox.Text, out int id))
            {
                Product searchedProduct = Inventory.LookupProduct(id);
                if (searchedProduct == null)
                {
                    MessageBox.Show("Product not found");
                    return;
                }

                foreach (DataGridViewRow item in productsGrid.Rows)
                {
                    if (((Product)item.DataBoundItem).ProductID == searchedProduct.ProductID)
                    {
                        item.Selected = true;
                        found = true;
                        break;
                    }
                }
            }
            else // if it isnt int search for name
            {
                Product searchedProduct = Inventory.LookupProduct(productsTextBox.Text);

                foreach (DataGridViewRow item in productsGrid.Rows)
                {
                    if (((Product)item.DataBoundItem) == searchedProduct)
                    {
                        item.Selected = true;
                        found = true;
                        break;
                    }
                }
            }
            if (!found || productsTextBox.Text == "")
            {
                MessageBox.Show("Product not found.");
            }
        }
        private void addProductButton_Click(object sender, EventArgs e)
        {
            new AddProduct().ShowDialog();
        }

        private void modifyProductButton_Click(object sender, EventArgs e)
        {
            new ModifyProduct((Product)productsGrid.SelectedRows[0].DataBoundItem).ShowDialog();
        }

        private void deleteProductButton_Click(object sender, EventArgs e)
        {
            Product product = (Product)productsGrid.CurrentRow.DataBoundItem;

            if ((product.AssociatedParts.Count() > 0))
            {
                MessageBox.Show("Product can not be deleted because it has parts associated with it.");
                return;
            }
            else
            {
                //Verify if user wants to delete product
                if (MessageBox.Show("Are you sure you want to delete this product?", "Delete Product?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    productsGrid.Rows.Remove(productsGrid.SelectedRows[0]);
                }
            }
        }
        #endregion

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
