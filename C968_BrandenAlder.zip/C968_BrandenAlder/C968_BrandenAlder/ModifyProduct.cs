﻿using C968_BrandenAlder.Models;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace C968_BrandenAlder
{
    public partial class ModifyProduct : Form
    {
        BindingList<Part> addedParts = new BindingList<Part>();
        BindingList<Part> modifiedParts = new BindingList<Part>();

        public ModifyProduct()
        {
            InitializeComponent();
        }
        public ModifyProduct(Product prod)
        {
            InitializeComponent();

            // fill in info
            FillFields(prod);

            // bind all candidate parts
            var allPartsBinding = new BindingSource();
            allPartsBinding.DataSource = Inventory.AllParts;
            allPartsGrid.DataSource = allPartsBinding;

            addedParts = prod.AssociatedParts;
            modifiedParts = new BindingList<Part>(addedParts.ToList());

            // bind parts associated with product
            var associatedPartsBinding = new BindingSource();
            associatedPartsBinding.DataSource = modifiedParts;
            associatedPartsGridView.DataSource = associatedPartsBinding;
        }

        #region Events
        private void searchCandidatePartsButton_Click(object sender, EventArgs e)
        {
            bool found = false;

            // Search by ID or NAME
            if (int.TryParse(searchPartsBox.Text, out int id))
            {
                Part searchedPart = Inventory.LookupPart(id);
                if (searchedPart == null)
                {
                    MessageBox.Show("Part not found");
                    return;
                }


                foreach (DataGridViewRow item in allPartsGrid.Rows)
                {
                    if (((Part)item.DataBoundItem).PartID == searchedPart.PartID)
                    {
                        item.Selected = true;
                        found = true;
                        break;
                    }
                }
            }
            else // if it isnt int search for name
            {
                Part searchedPart = Inventory.LookupPart(allPartsGrid.Text);

                foreach (DataGridViewRow item in allPartsGrid.Rows)
                {
                    if (((Part)item.DataBoundItem) == searchedPart)
                    {
                        item.Selected = true;
                        found = true;
                        break;
                    }
                }
            }
            if (!found)
            {
                MessageBox.Show("Part not found.");
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        { 
            modifiedParts.Add((Part)allPartsGrid.SelectedRows[0].DataBoundItem);
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (associatedPartsGridView.Rows.Count > 0)
            {
                if (MessageBox.Show("Are you sure you want to delete this part?", "Delete Part?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                { 
                    modifiedParts.Remove((Part)associatedPartsGridView.SelectedRows[0].DataBoundItem);
                }
                else
                {
                    return;
                }
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Parse text fields..
                int productID = int.Parse(idTextBox.Text);
                string name = nameTextBox.Text;
                int inventory = int.Parse(inventoryTextBox.Text);
                decimal price = decimal.Parse(priceCostTextBox.Text);
                int min = int.Parse(minTextBox.Text);
                int max = int.Parse(maxTextBox.Text);

                // Exception checks
                if (min > max)
                {
                    MessageBox.Show("Minimum quantity of parts can not be greater than maximum.");
                    return;
                }
                if (inventory < min || inventory > max)
                {
                    MessageBox.Show("The quantity of items in inventory must be between the minimum and maximum values.");
                    return;
                }

                // Update product 
                Product prod = Inventory.LookupProduct(productID);
                prod.ProductID = productID;
                prod.Name = name;
                prod.InStock = inventory;
                prod.Price = price;
                prod.Min = min;
                prod.Max = max;
                prod.AssociatedParts = modifiedParts;

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("inventory, price, min, and max need to be numbers.");
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            modifiedParts.Clear();
            foreach (Part part in addedParts)
            {
                modifiedParts.Add(part);
            }
            this.Close();
        }
        #endregion
        #region Methods
        private void FillFields(Product prod)
        {
            idTextBox.Text = prod.ProductID.ToString();
            nameTextBox.Text = prod.Name;
            inventoryTextBox.Text = prod.InStock.ToString();
            priceCostTextBox.Text = prod.Price.ToString();
            maxTextBox.Text = prod.Max.ToString();
            minTextBox.Text = prod.Min.ToString();
        }
        #endregion
    }
}
