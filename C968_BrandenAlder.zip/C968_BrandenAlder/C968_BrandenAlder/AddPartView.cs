﻿using C968_BrandenAlder.Models;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace C968_BrandenAlder
{
    public partial class AddPartView : Form
    {
        public AddPartView()
        {
            InitializeComponent();
            idTextBox.Text = (Inventory.AllParts.Count()).ToString(); 
        }
        #region Events
        private void inhouseRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            changingLabel.Text = "Machine ID";
        }

        private void outsourcedRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            changingLabel.Text = "Company Name";
        }

        // Closes add part view and goes back to main screen
        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            // Try parsing all the values
            try
            {
                int partID = int.Parse(idTextBox.Text);
                string name = nameTextBox.Text;
                int inventory = int.Parse(inventoryTextBox.Text);
                decimal price = decimal.Parse(priceCostTextBox.Text);
                int min = int.Parse(minTextBox.Text);
                int max = int.Parse(maxTextBox.Text);

                // Exception checks - making sure everything is in range
                if (min > max)
                {
                    MessageBox.Show("Minimum quantity of parts can not be greater than maximum.");
                    return;
                }
                if (inventory < min || inventory > max)
                {
                    MessageBox.Show("The quantity of items in inventory must be between the minimum and maximum values.");
                    return;
                }

                // Creating part depending on radiobutton selection
                if (inhouseRadioButton.Checked)
                {
                    Inventory.AddPart(new Inhouse(partID, int.Parse(machineIdTextBox.Text), name, inventory, price, min, max));
                    this.Close();
                }
                else
                {
                    Inventory.AddPart(new Outsourced(partID, machineIdTextBox.Text, name, inventory, price, min, max));
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Machine ID, Inventory, Min, max, and price need to be numbers.");
            }
        }
        #endregion

        // IGNORE PLEASE: This isnt in requirements (saving in case it actually is needed) // 
        #region TextBox Text Change Events
        private void inventoryTextBox_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(inventoryTextBox.Text, out int _))
            {
                inventoryTextBox.BackColor = Color.White;
            }
            else
            {
                inventoryTextBox.BackColor = Color.Crimson;
            }
        }

        private void priceCostTextBox_TextChanged(object sender, EventArgs e)
        {
            if (decimal.TryParse(priceCostTextBox.Text, out decimal _))
            {
                priceCostTextBox.BackColor = Color.White;
            }
            else
            {
                priceCostTextBox.BackColor = Color.Crimson;
            }
        }

        private void maxTextBox_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(maxTextBox.Text, out int _))
            {
                maxTextBox.BackColor = Color.White;
            }
            else
            {
                maxTextBox.BackColor = Color.Crimson;
            }
        }

        private void minTextBox_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(minTextBox.Text, out int _))
            {
                minTextBox.BackColor = Color.White;
            }
            else
            {
                minTextBox.BackColor = Color.Crimson;
            }
        }

        private void machineIdTextBox_TextChanged(object sender, EventArgs e)
        {
            if(inhouseRadioButton.Checked)
            {
                if(!int.TryParse(machineIdTextBox.Text, out int _))
                {
                    machineIdTextBox.BackColor = Color.Crimson;
                }
                else
                {
                    machineIdTextBox.BackColor = Color.White;
                }
            }
        }
        #endregion
    }
}
